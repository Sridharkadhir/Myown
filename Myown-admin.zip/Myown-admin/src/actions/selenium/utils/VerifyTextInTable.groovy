package actions.selenium.utils;


class VerifyTextInTable{
    public void run(def params){
        
    }
}