package actions.selenium.utils;


class AutoITDownloadFiles{
    public void run(def params){
        
    }
}